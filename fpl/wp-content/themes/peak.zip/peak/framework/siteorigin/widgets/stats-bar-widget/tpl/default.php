<?php
/**
 * @var $title
 * @var $value
 */


echo do_shortcode('[stats_bar title="' . $title . '" value="' . $value . '" ]');
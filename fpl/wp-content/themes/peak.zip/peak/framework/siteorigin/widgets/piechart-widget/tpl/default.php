<?php
/**
 * @var $percent
 * @var $title
 * @var $bar_color
 */


echo do_shortcode('[piechart percent="' . $percent . '" title="' . $title . '" bar_color="' . $bar_color . '" ]');
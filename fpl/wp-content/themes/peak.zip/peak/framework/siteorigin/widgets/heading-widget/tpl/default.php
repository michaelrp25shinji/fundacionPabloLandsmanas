
<?php
/**
 * @var $style
 * @var $class
 * @var $align
 * @var $title
 * @var $pitch_text
 */


echo do_shortcode('[heading style="' . $style . '" class="' . $class . '" align="' . $align . '" title="' . $title . '" pitch_text="' . $pitch_text . '" ]');


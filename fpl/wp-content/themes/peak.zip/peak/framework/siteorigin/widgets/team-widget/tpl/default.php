<?php
/**
 * @var $post_count
 * @var $column_count
 * @var $member_ids
 */


echo do_shortcode('[team post_count="' . $post_count . '" column_count="' . $column_count . '" member_ids="' . $member_ids . '" ]');
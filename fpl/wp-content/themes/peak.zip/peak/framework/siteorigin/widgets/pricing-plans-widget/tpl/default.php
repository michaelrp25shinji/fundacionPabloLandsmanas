<?php
/**
 * @var $post_count
 * @var $pricing_ids
 */


echo do_shortcode('[pricing_plans post_count="' . $post_count . '" pricing_ids="' . $pricing_ids . '" ]');
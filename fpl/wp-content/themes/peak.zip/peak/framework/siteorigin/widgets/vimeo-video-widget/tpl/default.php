<?php
/**
 * @var $vimeo_video_id
 * @var $placeholder_id
 */


echo do_shortcode('[vimeo_video vimeo_video_id="' . $vimeo_video_id . '" placeholder_id="' . $placeholder_id . '" ]');


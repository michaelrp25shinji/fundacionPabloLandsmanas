<?php
/**
 * @var $post_count
 * @var $taxonomy
 * @var $terms
 */


echo do_shortcode('[post_listing post_count="' . $post_count . '" taxonomy="' . $taxonomy . '" terms="' . $terms . '" ]');
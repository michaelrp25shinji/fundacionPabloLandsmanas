<?php
/**
 * Template Name: Gallery
 *
 * A custom page template for displaying gallery items
 *
 * @package Peak
 * @subpackage Template
 */


get_template_part('loop', 'gallery');
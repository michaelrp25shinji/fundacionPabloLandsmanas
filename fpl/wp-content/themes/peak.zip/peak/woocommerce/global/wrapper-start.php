<?php

echo '<div id="content" class="' . mo_get_content_class() . '">';
echo '<div class="hfeed">';
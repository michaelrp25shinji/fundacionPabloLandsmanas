<?php

echo '</div><!-- .hfeed -->';
echo '</div><!-- #content -->';
<?php
/**
 *
 * Displays campaign items belonging to specific campaign categories
 *
 * @package Peak
 * @subpackage Template
 */

get_template_part('loop', 'campaign');
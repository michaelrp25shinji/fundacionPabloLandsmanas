<?php
/**
 *
 * Template Name: Campaigns
 *
 * Displays all the campaigns configured for the site
 *
 * @package Peak
 * @subpackage Template
 */

get_template_part('loop', 'campaign');
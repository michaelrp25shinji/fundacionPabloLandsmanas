<?php
/**
 *
 * Displays gallery items belonging to specific gallery categories
 *
 * @package Peak
 * @subpackage Template
 */

get_template_part('loop', 'gallery');
<?php
/**
 * Sidebar template
 *
 * Display sidebars for the posts/pages
 *
 * @package Peak
 * @subpackage Template
 */

$sidebar_manager = mo_get_sidebar_manager();
$sidebar_manager->populate_sidebars();
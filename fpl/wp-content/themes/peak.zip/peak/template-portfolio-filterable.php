<?php
/**
 * Template Name: Filterable Portfolio
 *
 * A custom page template for displaying portfolio items filtered by portfolio category
 *
 * @package Peak
 * @subpackage Template
 */

get_template_part('loop', 'portfolio');
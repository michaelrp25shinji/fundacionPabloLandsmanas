<?php
/**
 * Template Name: Filterable Campaigns
 *
 * A custom page template for displaying campaigns filtered by campaign category
 *
 * @package Peak
 * @subpackage Template
 */

get_template_part('loop', 'campaign');